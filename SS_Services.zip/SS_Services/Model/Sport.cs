﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace EventHub.Model
{
    public class Sport
    {
        string name;

        #region PROPERTIES
        string Name { get; set; }
        #endregion
        Sport()
        {
        }
    }
}
